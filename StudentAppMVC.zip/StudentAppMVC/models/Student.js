// ...existing code...
const db = require('../db');

const StudentModel = {
  // Get all students
  getAll: function(callback) {
    const sql = 'SELECT studentId, name, dob, contact, image FROM students ORDER BY name';
    db.query(sql, (err, results) => {
      if (err) return callback(err);
      callback(null, results);
    });
  },

  // Get a student by ID
  getById: function(studentId, callback) {
    const sql = 'SELECT studentId, name, dob, contact, image FROM students WHERE studentId = ? LIMIT 1';
    db.query(sql, [studentId], (err, results) => {
      if (err) return callback(err);
      const student = results && results.length ? results[0] : null;
      callback(null, student);
    });
  },

  // Add a new student
  // student: { name, dob, contact, image }
  add: function(student, callback) {
    const sql = 'INSERT INTO students (name, dob, contact, image) VALUES (?, ?, ?, ?)';
    const params = [student.name, student.dob, student.contact, student.image];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      // return the new record id
      callback(null, { insertId: result.insertId });
    });
  },

  // Update an existing student by ID
  // student: { name, dob, contact, image }
  update: function(studentId, student, callback) {
    const sql = 'UPDATE students SET name = ?, dob = ?, contact = ?, image = ? WHERE studentId = ?';
    const params = [student.name, student.dob, student.contact, student.image, studentId];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows, changedRows: result.changedRows });
    });
  },

  // Delete a student by ID
  delete: function(studentId, callback) {
    const sql = 'DELETE FROM students WHERE studentId = ?';
    db.query(sql, [studentId], (err, result) => {
      if (err) return callback(err);
      callback(null, { affectedRows: result.affectedRows });
    });
  }
};

module.exports = StudentModel;
// ...existing code...