// ...existing code...
const Student = require('../models/Student');

const studentController = {
  // List all students and render index view
  list: (req, res) => {
    Student.getAll((err, students) => {
      if (err) return res.status(500).send('Database error');
      // add a display-friendly DOB field
      students = (students || []).map(s => ({
        ...s,
        dobFormatted: s.dob ? new Date(s.dob).toISOString().slice(0,10) : ''
      }));
      res.render('index', { students });
    });
  },

  // Get single student and render view
  getById: (req, res) => {
    const id = req.params.id || req.params.studentId;
    Student.getById(id, (err, student) => {
      if (err) return res.status(500).send('Database error');
      if (!student) return res.status(404).send('Student not found');
      student.dobFormatted = student.dob ? new Date(student.dob).toISOString().slice(0,10) : '';
      res.render('student', { student });
    });
  },

  // Add student then redirect to list
  add: (req, res) => {
    const student = {
      name: req.body.name,
      dob: req.body.dob,
      contact: req.body.contact,
      image: req.file ? req.file.filename : (req.body.image || null)
    };
    Student.add(student, (err) => {
      if (err) return res.status(500).send('Database error');
      res.render('editStudent', { student });
    });
  },

  // Update student then redirect to list
  update: (req, res) => {
    const id = req.params.id || req.params.studentId;
    const student = {
      name: req.body.name,
      dob: req.body.dob,
      contact: req.body.contact,
      image: req.file ? req.file.filename : req.body.image
    };
    Student.update(id, student, (err) => {
      if (err) return res.status(500).send('Database error');
      res.redirect('/');
    });
  },

  // Delete student then redirect to list
  delete: (req, res) => {
    const id = req.params.id || req.params.studentId;
    Student.delete(id, (err) => {
      if (err) return res.status(500).send('Database error');
      res.redirect('/');
    });
  }
};

module.exports = studentController;
// ...existing code...