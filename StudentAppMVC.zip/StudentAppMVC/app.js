const express = require('express');
const multer = require('multer');
const app = express();

// Import controller and model
const studentController = require('./controllers/studentControllers');
const Student = require('./models/Student');

// Set up multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images'); // Directory to save uploaded files
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});
const upload = multer({ storage: storage });

// Set up view engine
app.set('view engine', 'ejs');
// enable static files
app.use(express.static('public'));
// enable form processing
app.use(express.urlencoded({ extended: false }));

// Routes using controller methods

// List all students
app.get('/', studentController.list);

// View a single student
app.get('/student/:id', studentController.getById);

// Render add form
app.get('/addStudent', (req, res) => {
    res.render('addStudent');
});

// Add student (with file upload)
app.post('/addStudent', upload.single('image'), studentController.add);

// Render edit form (uses model to fetch student and render edit view)
app.get('/editStudent/:id',studentController.updateForm, (req, res) => {
    const id = req.params.id;
    Student.getById(id, (err, student) => {
        if (err) {
            console.error('Error fetching student for edit:', err);
            return res.status(500).send('Error retrieving student');
        }
        if (!student) return res.status(404).send('Student not found');
        res.render('editStudent', { student });
    });
});

// Update student (with file upload)
app.post('/editStudent/:id', upload.single('image'), studentController.update);

// Delete student
app.get('/deleteStudent/:id', studentController.delete);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
