// ...existing code...
const Supermarket = require('../models/Supermarket');

module.exports = {
    // List all products
    listAll(req, res) {
        Supermarket.getAll((err, results) => {
            if (err) return res.status(500).json({ error: 'Database error', details: err });
            return res.json(results);
        });
    },

    // Get product by ID
    getById(req, res) {
        const id = req.params.id;
        Supermarket.getById(id, (err, product) => {
            if (err) return res.status(500).json({ error: 'Database error', details: err });
            if (!product) return res.status(404).json({ message: 'Product not found' });
            return res.json(product);
        });
    },

    // Add a new product
    add(req, res) {
        const product = {
            productName: req.body.productName,
            price: req.body.price,
            quantity: req.body.quantity,
            image: req.body.image
        };
        Supermarket.add(product, (err, result) => {
            if (err) return res.status(500).json({ error: 'Database error', details: err });
            return res.status(201).json({ message: 'Product created', id: result.insertId });
        });
    },

    // Update an existing product
    update(req, res) {
        const id = req.params.id;
        const product = {
            productName: req.body.productName,
            price: req.body.price,
            quantity: req.body.quantity,
            image: req.body.image
        };
        Supermarket.update(id, product, (err, result) => {
            if (err) return res.status(500).json({ error: 'Database error', details: err });
            if (result.affectedRows === 0) return res.status(404).json({ message: 'Product not found' });
            return res.json({ message: 'Product updated', changedRows: result.changedRows });
        });
    },

    // Delete a product
    delete(req, res) {
        const id = req.params.id;
        Supermarket.delete(id, (err, result) => {
            if (err) return res.status(500).json({ error: 'Database error', details: err });
            if (result.affectedRows === 0) return res.status(404).json({ message: 'Product not found' });
            return res.json({ message: 'Product deleted' });
        });
    }
};
// ...existing code...