// ...existing code...
const db = require('../db');

/**
 * Function-based model for supermarket / students table
 * Fields assumed: id, productName, price, quantity, image
 * Table name used: students
 */

function getAll(callback) {
    const sql = 'SELECT id, productName, price, quantity, image FROM students';
    db.query(sql, (err, results) => {
        return callback(err, results);
    });
}

function getById(id, callback) {
    const sql = 'SELECT id, productName, price, quantity, image FROM students WHERE id = ?';
    db.query(sql, [id], (err, results) => {
        // return single row or null for consistency
        if (err) return callback(err);
        return callback(null, results.length ? results[0] : null);
    });
}

function add(product, callback) {
    // product: { productName, price, quantity, image }
    const sql = 'INSERT INTO students (productName, price, quantity, image) VALUES (?, ?, ?, ?)';
    const params = [product.productName, product.price, product.quantity, product.image];
    db.query(sql, params, (err, result) => {
        if (err) return callback(err);
        // return inserted id and affectedRows for caller convenience
        return callback(null, { insertId: result.insertId, affectedRows: result.affectedRows });
    });
}

function update(id, product, callback) {
    // product: { productName, price, quantity, image }
    const sql = 'UPDATE students SET productName = ?, price = ?, quantity = ?, image = ? WHERE id = ?';
    const params = [product.productName, product.price, product.quantity, product.image, id];
    db.query(sql, params, (err, result) => {
        if (err) return callback(err);
        return callback(null, { affectedRows: result.affectedRows, changedRows: result.changedRows });
    });
}

function remove(id, callback) {
    const sql = 'DELETE FROM students WHERE id = ?';
    db.query(sql, [id], (err, result) => {
        if (err) return callback(err);
        return callback(null, { affectedRows: result.affectedRows });
    });
}

module.exports = {
    getAll,
    getById,
    add,
    update,
    delete: remove
};
// ...existing code...